
public class DefensorEternia {
    private int id;
    private String nombre;
    private String habilidadEspecial;
    private int nivelDePoder;
    private String region;

    // Constructor
    public DefensorEternia(int id, String nombre, String habilidadEspecial, int nivelDePoder, String region) {
        this.id = id;
        this.nombre = nombre;
        this.habilidadEspecial = habilidadEspecial;
        this.nivelDePoder = nivelDePoder;
        this.region = region;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getHabilidadEspecial() {
        return habilidadEspecial;
    }

    public int getNivelDePoder() {
        return nivelDePoder;
    }

    public String getRegion() {
        return region;
    }

    // Setters (if needed, for editable fields in search, we might need setters for name, etc.
    // For this exercise, we'll assume ID is the primary key and others are displayed)
    // If you need to make them editable for actual updates later, add setters here.
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setHabilidadEspecial(String habilidadEspecial) {
        this.habilidadEspecial = habilidadEspecial;
    }

    public void setNivelDePoder(int nivelDePoder) {
        this.nivelDePoder = nivelDePoder;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Nombre: " + nombre + ", Habilidad: " + habilidadEspecial +
                ", Nivel: " + nivelDePoder + ", Región: " + region;
    }
}
