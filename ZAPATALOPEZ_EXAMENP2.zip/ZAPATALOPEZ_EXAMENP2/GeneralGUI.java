import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List; // Import List for getAllDefenders

public class GeneralGUI extends JFrame { // Extend JFrame to make it a top-level window
    private JPanel mainPanel; // Assuming you have a main panel in your form
    private JTextField txt1; // ID
    private JTextField txt2; // Nombre
    private JComboBox<String> cbo1; // Habilidad Especial
    private JComboBox<String> cbo2; // Nivel de Poder
    private JComboBox<String> cbo3; // Región
    private JButton agregarButton; // Add button
    private JTable defendersTable; // Table to display defenders
    private JTextField searchIdTxt; // Text field for search ID
    private JButton searchButton; // Button for search


    private Defensor defensorList; // Instance of our linked list

    public GeneralGUI() {




        defensorList = new Defensor(); // Initialize the linked list

        // Populate ComboBoxes (assuming these are not automatically populated by the designer)
        populateComboBoxes();

        // Initialize the table model
        setupDefendersTable();

        agregarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addDefender();
            }
        });

        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                searchDefender();
            }
        });

        // Initial load of data into the table (if any pre-existing)
        updateDefendersTable();
    }

    private void populateComboBoxes() {
        // Habilidad Especial
        cbo1.addItem("Fuerza Titanes");
        cbo1.addItem("Espada de Poder");
        cbo1.addItem("Estrategia Bélica");
        cbo1.addItem("Magia Ancestral");
        cbo1.addItem("Tecnología Avanzada");

        // Nivel de Poder (1-10)
        for (int i = 1; i <= 10; i++) {
            cbo2.addItem(String.valueOf(i));
        }

        // Región
        cbo3.addItem("Castillo Grayskull");
        cbo3.addItem("Villa Real");
        cbo3.addItem("Montañas Místicas");
        cbo3.addItem("Torre del Viento");
        cbo3.addItem("Bosque de la Eternidad");
    }

    private void setupDefendersTable() {
        String[] columnNames = {"ID", "Nombre", "Habilidad Especial", "Nivel de Poder", "Región"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Make cells non-editable in the table directly, editing will be via search fields
                return false;
            }
        };
        defendersTable.setModel(model);
    }

    private void addDefender() {
        try {
            int id = Integer.parseInt(txt1.getText().trim());
            String nombre = txt2.getText().trim();
            String habilidadEspecial = (String) cbo1.getSelectedItem();
            int nivelPoder = Integer.parseInt(cbo2.getSelectedItem().toString());
            String region = (String) cbo3.getSelectedItem();

            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(null, "El nombre no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            DefensorEternia newDefender = new DefensorEternia(id, nombre, habilidadEspecial, nivelPoder, region);

            if (defensorList.insert(newDefender)) {
                JOptionPane.showMessageDialog(null, "Defensor agregado exitosamente.");
                clearInputFields();
                updateDefendersTable();
            } else {
                JOptionPane.showMessageDialog(null, "Error: Ya existe un defensor con el ID " + id, "Error de Registro", JOptionPane.ERROR_MESSAGE);
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "El ID y el Nivel de Poder deben ser números válidos.", "Error de Entrada", JOptionPane.ERROR_MESSAGE);
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(null, "Por favor, seleccione una habilidad y una región.", "Error de Selección", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void searchDefender() {
        try {
            int idToSearch = Integer.parseInt(searchIdTxt.getText().trim());
            DefensorEternia foundDefender = defensorList.findByID(idToSearch);

            if (foundDefender != null) {
                JOptionPane.showMessageDialog(null, "Defensor encontrado:\n" +
                        "ID: " + foundDefender.getId() + "\n" +
                        "Nombre: " + foundDefender.getNombre() + "\n" +
                        "Habilidad Especial: " + foundDefender.getHabilidadEspecial() + "\n" +
                        "Nivel de Poder: " + foundDefender.getNivelDePoder() + "\n" +
                        "Región: " + foundDefender.getRegion(), "Defensor Encontrado", JOptionPane.INFORMATION_MESSAGE);

                // Populate editable fields (assuming you want to enable editing after search)
                txt1.setText(String.valueOf(foundDefender.getId()));
                txt2.setText(foundDefender.getNombre());
                cbo1.setSelectedItem(foundDefender.getHabilidadEspecial());
                cbo2.setSelectedItem(String.valueOf(foundDefender.getNivelDePoder()));
                cbo3.setSelectedItem(foundDefender.getRegion());

                // Potentially enable an "Update" button here if you want to allow modifications
                // For now, we'll just display and populate the fields.
            } else {
                JOptionPane.showMessageDialog(null, "Advertencia: No se encontró ningún defensor con el ID " + idToSearch, "Defensor No Encontrado", JOptionPane.WARNING_MESSAGE);
                clearInputFields(); // Clear fields if not found
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Por favor, ingrese un ID numérico válido para la búsqueda.", "Error de Entrada", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateDefendersTable() {
        DefaultTableModel model = (DefaultTableModel) defendersTable.getModel();
        model.setRowCount(0); // Clear existing data

        List<DefensorEternia> allDefenders = defensorList.getAllDefenders();
        for (DefensorEternia defender : allDefenders) {
            model.addRow(new Object[]{
                    defender.getId(),
                    defender.getNombre(),
                    defender.getHabilidadEspecial(),
                    defender.getNivelDePoder(),
                    defender.getRegion()
            });
        }
    }

    private void clearInputFields() {
        txt1.setText("");
        txt2.setText("");
        cbo1.setSelectedIndex(0); // Reset to first item
        cbo2.setSelectedIndex(0); // Reset to first item (level 1)
        cbo3.setSelectedIndex(0); // Reset to first item
        searchIdTxt.setText(""); // Clear search field as well
    }

    public static void main(String[] args) {
        // Run the GUI on the Event Dispatch Thread
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new GeneralGUI().setVisible(true);
            }
        });
    }
}
