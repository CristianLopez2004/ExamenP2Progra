

import java.util.ArrayList;
import java.util.List;

public class Defensor {

    private Node head;

    // Node class for the linked list
    private static class Node {
        DefensorEternia data;
        Node next;

        Node(DefensorEternia data) {
            this.data = data;
            this.next = null;
        }
    }

    public Defensor() {
        this.head = null;
    }

    /**
     * Inserts a new DefensorEternia into the list.
     * If the ID already exists, returns false (error).
     * Otherwise, adds to the end and returns true.
     * @param newDefender The DefensorEternia object to insert.
     * @return true if inserted successfully, false if ID already exists.
     */
    public boolean insert(DefensorEternia newDefender) {
        if (findByID(newDefender.getId()) != null) {
            // ID already exists
            return false;
        }

        Node newNode = new Node(newDefender);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
        return true;
    }

    /**
     * Performs a linear search for a DefensorEternia by ID.
     * @param id The ID to search for.
     * @return The DefensorEternia object if found, null otherwise.
     */
    public DefensorEternia findByID(int id) {
        Node current = head;
        while (current != null) {
            if (current.data.getId() == id) {
                return current.data;
            }
            current = current.next;
        }
        return null; // Not found
    }

    /**
     * Returns a List of DefensorEternia objects for displaying in JTable.
     * @return A List containing all DefensorEternia objects in the list.
     */
    public List<DefensorEternia> getAllDefenders() {
        List<DefensorEternia> defenders = new ArrayList<>();
        Node current = head;
        while (current != null) {
            defenders.add(current.data);
            current = current.next;
        }
        return defenders;
    }

    /**
     * Updates an existing defender's information (excluding ID).
     * @param updatedDefender The defender object with updated information (ID must match an existing one).
     * @return true if the defender was found and updated, false otherwise.
     */
    public boolean update(DefensorEternia updatedDefender) {
        Node current = head;
        while (current != null) {
            if (current.data.getId() == updatedDefender.getId()) {
                current.data.setNombre(updatedDefender.getNombre());
                current.data.setHabilidadEspecial(updatedDefender.getHabilidadEspecial());
                current.data.setNivelDePoder(updatedDefender.getNivelDePoder());
                current.data.setRegion(updatedDefender.getRegion());
                return true;
            }
            current = current.next;
        }
        return false;
    }
}