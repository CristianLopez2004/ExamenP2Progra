import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.HierarchyBoundsAdapter;

public class General {
    private JTable tbl1;
    private JTextField txt1;
    private JComboBox cbo1;
    private JTextField txt2;
    private JComboBox cbo2;
    private JComboBox cbo3;
    private JButton btn1;

    public General() {
        tbl1.addHierarchyBoundsListener(new HierarchyBoundsAdapter() {
        });
        btn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
