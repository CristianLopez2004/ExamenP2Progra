public class DefensorEternia {
    //Atributps del Defensor

    int ID;
    String Nombre;
    String HabilidadEspecial;
    int NivelPoder;
    String Region;


//Conttructor
    public DefensorEternia(int ID, String nombre, int nivelPoder, String habilidadEspecial, String region) {
        this.ID = ID;
        Nombre = nombre;
        NivelPoder = nivelPoder;
        HabilidadEspecial = habilidadEspecial;
        Region = region;
    }

//getterrrs

    public int getID() {
        return ID;
    }

    public String getNombre() {
        return Nombre;
    }

    public String getHabilidadEspecial() {
        return HabilidadEspecial;
    }

    public int getNivelPoder() {

        return NivelPoder;

    }


    public String getRegion() {
        return Region;
    }

    //Setterrs


    public void setID(int ID) {
        this.ID = ID;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public void setHabilidadEspecial(String habilidadEspecial) {
        HabilidadEspecial = habilidadEspecial;
    }

    public void setNivelPoder(int nivelPoder) {
        NivelPoder = nivelPoder;
    }

    public void setRegion(String region) {
        Region = region;
    }

    // el to string
    @Override
    public String toString() {
        return "DefensorEternia{" +
                "ID=" + ID +
                ", Nombre='" + Nombre + '\'' +
                ", HabilidadEspecial='" + HabilidadEspecial + '\'' +
                ", NivelPoder=" + NivelPoder +
                ", Region='" + Region + '\'' +
                '}';
    }

}
