public class NodoDefensor {

    DefensorEternia info; //INFORMACION DEL DEFENSERO ETERNIAA COMO SU NOMBRE PODER,ETCCC
    NodoDefensor sig;
    //  Costructor del NodoDefensor para incializadr sis valores
    public NodoDefensor(DefensorEternia info){

        this.info = info;
        this.sig = null;// tiene estar vacio

    }
}
