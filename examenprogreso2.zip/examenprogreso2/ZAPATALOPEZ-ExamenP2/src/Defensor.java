import javax.swing.*;
import java.time.temporal.TemporalAmount;
import java.util.ArrayList;
import java.util.List;

public class Defensor {

    //declaramos un inicio y fin para los nodos
   //ademas del tamaño para control

    private NodoDefensor inicio;
    private NodoDefensor fin;
    private int tamano;
    // contructor incializando en vacio el inicion y fin y en 0 el contador

    public Defensor(){
        this.inicio = null;
        this.fin = null;
        this.tamano = 0;
    }
//metodo para insertar los defensores
    public boolean insertarDefensor(DefensorEternia nuevoDefensor){

        if(encontrarID(nuevoDefensor.getID()) != null){

            return false; // este verdadero o falsoo verifica pues si existe algun id ya


            JOptionPane.showConfirmDialog(null, "Error ya existe ese id");

        }
        NodoDefensor nuevoNodo = new NodoDefensor(nuevoDefensor);

        if(inicio == null){
            inicio = nuevoDefensor;
            fin = nuevoDefensor;
        }else{
            fin.sig = nuevoNodo;
            fin = nuevoNodo;
        }

        tamano++;

        return true;

    }

    public DefensorEternia encontrarID(int ID){
        NodoDefensor actual = inicio;
        while (actual != null){
            if(actual.info.getID() == ID) {
                return actual.info;

            }
            actual = actual.sig;
        }
        return null;
    }

    public DefensorEternia[] obtenerTodoslosdefensores(){

        DefensorEternia[] defensoritos = new DefensorEternia[tamano];
        NodoDefensor actual = inicio;
        int i= 0;
        while(actual != null){
            defensoritos[i++] = actual.info;
            actual = actual.sig;
        }
        return defensoritos;

    }

    public List<DefensorEternia> toList(){
        List<DefensorEternia> lista  = new ArrayList<>();

        NodoDefensor actual = inicio;
         while(actual != null){
             lista.add(actual.info);
             actual = actual.sig;

         }
         return lista;
    }

public int getTamano(){
        return tamano;
}

public boolean isEmpty(){
        return inicio == null;
}




}
